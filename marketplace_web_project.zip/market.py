
from flask import Flask, request, session, redirect, url_for, render_template, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta
import sqlite3
import os
import re
import html
from functools import wraps
import secrets
import time

app = Flask(__name__)
app.secret_key = os.urandom(32)
app.permanent_session_lifetime = timedelta(minutes=30)
DATABASE = "market_final.db"

# =================== COOKIE CONFIGURATION ===================
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Strict',
    SESSION_COOKIE_SECURE=True
)

# =================== DATABASE SETUP ===================
def init_db():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        master_key_hash TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS shops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        shop_name TEXT,
        approved INTEGER DEFAULT 0,
        fee_percent REAL DEFAULT 6.0,
        shop_balance REAL DEFAULT 0.0
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        shop_id INTEGER,
        product_name TEXT,
        description TEXT,
        price REAL,
        approved INTEGER DEFAULT 0
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        buyer_id INTEGER,
        amount REAL,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS escrow (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        buyer_id INTEGER,
        shop_id INTEGER,
        product_name TEXT,
        amount REAL,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER,
        receiver_id INTEGER,
        message TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        shop_id INTEGER,
        user_id INTEGER,
        stars REAL,
        comment TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    conn.commit()
    conn.close()

# =================== DB HELPERS ===================
def query_db(query, args=(), one=False):
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(query, args)
    data = cur.fetchall()
    conn.commit()
    conn.close()
    return (data[0] if data else None) if one else data

# =================== AUDIT LOG ===================
def log_action(user_id, action):
    query_db("INSERT INTO audit_log (user_id, action) VALUES (?, ?)", (user_id, action))

# =================== CLEANUP ===================
def cleanup_messages():
    query_db("DELETE FROM messages WHERE timestamp < datetime('now', '-1 day')")

# =================== RATING LOGIC ===================
def check_shop_rating(shop_id):
    ratings = query_db("SELECT stars FROM ratings WHERE shop_id=?", (shop_id,))
    if ratings:
        avg = sum([r['stars'] for r in ratings]) / len(ratings)
        if avg < 3.5:
            query_db("UPDATE shops SET approved=0 WHERE id=?", (shop_id,))

# =================== INPUT VALIDATION ===================
def sanitize_input(text):
    return html.escape(text.strip())

# =================== DECORATORS ===================
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("is_admin"):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

# =================== SECURITY HEADERS ===================
@app.after_request
def apply_security_headers(response):
    nonce = session.get('csp_nonce', '')
    headers = {
        "Content-Security-Policy": f"default-src 'self'; script-src 'self' 'nonce-{nonce}'; style-src 'self';",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Referrer-Policy": "no-referrer"
    }
    for k, v in headers.items():
        response.headers[k] = v
    return response

# =================== CSP NONCE INJECTION ===================
@app.context_processor
def inject_nonce():
    nonce = secrets.token_urlsafe(12)
    session['csp_nonce'] = nonce
    return dict(csp_nonce=nonce)

# =================== RATE LIMITING ===================
rate_limits = {}
failed_logins = {}

def limit_rate(ip, limit=10, window=60):
    now = time.time()
    if ip not in rate_limits:
        rate_limits[ip] = []
    rate_limits[ip] = [t for t in rate_limits[ip] if now - t < window]
    if len(rate_limits[ip]) >= limit:
        return False
    rate_limits[ip].append(now)
    return True

def record_failed_login(ip):
    now = time.time()
    if ip not in failed_logins:
        failed_logins[ip] = []
    failed_logins[ip] = [t for t in failed_logins[ip] if now - t < 300]
    failed_logins[ip].append(now)

def is_blocked(ip, threshold=5):
    return len(failed_logins.get(ip, [])) >= threshold

# =================== CSRF ===================
@app.before_request
def csrf_protect():
    if request.method == "POST":
        if request.content_type != "application/x-www-form-urlencoded":
            abort(400)
        token = session.get("csrf_token")
        form_token = request.form.get("csrf_token")
        if not token or not form_token or token != form_token:
            abort(403)

@app.context_processor
def inject_csrf_token():
    token = session.get("csrf_token") or secrets.token_hex(16)
    session["csrf_token"] = token
    return dict(csrf_token=token)

# =================== ROUTES ===================
@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.")
    return redirect(url_for("login"))

@app.route("/")
def index():
    return redirect(url_for("login"))

@app.route("/login")
def login():
    return "Login page (to be implemented)"

@app.route("/register")
def register():
    return "Register page (to be implemented)"

@app.route("/dashboard")
@login_required
def dashboard():
    return "User dashboard (to be implemented)"

@app.route("/admin")
@admin_required
def admin():
    return "Admin panel (to be implemented)"

@app.route("/create_shop")
@login_required
def create_shop():
    return "Create shop page"

@app.route("/add_product")
@login_required
def add_product():
    return "Add product page"

@app.route("/shop/<int:shop_id>")
def view_shop(shop_id):
    return f"Viewing shop {shop_id}"

@app.route("/product/<int:product_id>")
def view_product(product_id):
    return f"Viewing product {product_id}"

@app.route("/buy/<int:product_id>")
@login_required
def buy_product(product_id):
    return f"Buying product {product_id}"

@app.route("/messages")
@login_required
def messages():
    return "Messages page"

@app.route("/send_message")
@login_required
def send_message():
    return "Send message page"

@app.route("/orders")
@login_required
def orders():
    return "Orders list"

@app.route("/order/<int:order_id>")
@login_required
def view_order(order_id):
    return f"Viewing order {order_id}"

@app.route("/release_escrow/<int:order_id>")
@login_required
def release_escrow(order_id):
    return f"Release escrow for order {order_id}"

@app.route("/rate_shop/<int:shop_id>")
@login_required
def rate_shop(shop_id):
    return f"Rating shop {shop_id}"

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
